<html>
	<head>
		<meta charset="utf-8">
				<title>Bang Critic. Enjoy!</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="../../menu bar.css">
		<link href="../../content.css" rel="stylesheet" type="text/css">
        
        <link rel="stylesheet" type="text/css" media="screen and (max-width: 360px)" href="../../stylesheets/portrait.css">
		<link rel="stylesheet" type="text/css" media="screen and (min-width: 361px) and (max-width: 480px)" href="../../stylesheets/landscape.css">
		<link rel="stylesheet" type="text/css" media="screen and (min-width: 481px)" href="../../stylesheets/desktop.css">
     	
	</head>
	<body>
    	
        <div class="navbar navbar-fixed-top">
			<a class="navbar-brand" href="../../index.php">Bang Critic</a>
            <a href="../../index.php">Home</a>
		<div class="dropdown">
		<button class="dropbtn">Pics/Gifs 
			<i class="fa fa-caret-down"></i>
		</button>
			<div class="dropdown-content">
				<a href="../Gifs/gifs.php">Gifs</a>
				<a href="../Pictures/Pictures.php">Pictures</a>
				<a href="../Categories/All Categories.php">All Categories...</a>
			</div>
		</div>
			<div class="dropdown">
		<button class="dropbtn">Movies
			<i class="fa fa-caret-down"></i>
		</button>
			<div class="dropdown-content">
				<a href="../Movies/Ebony/Ebony.php">Ebony</a>
				<a href="../Movies/Hentai/Hentai.php">Hentai</a>
				<a href="../Movies/Milf/Milf.php">Milf</a>
				<a href="../Movies/Teen/Teen.php">Teen</a>
				<a href="../Movies/Categories/All Categories.php">All Categories...</a>
			</div>
		</div>
			<a href="../../sign/login.php">Login</a>
			<a href="../../sign/register.php">Register</a>
			<a href="../../page's/about_us.html">About us</a>
			<a href="../../sign/profile.php">Account</a>
		</div>
        
    <div class="container">
		<h1>....</h1>
        	<p1>....</p1>
    </div>
    
    
    </body>
</html>