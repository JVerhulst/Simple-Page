<?php


$conn=mysqli_connect("localhost","root","","userlogin") or die("The connection to the database has not been made");





?>